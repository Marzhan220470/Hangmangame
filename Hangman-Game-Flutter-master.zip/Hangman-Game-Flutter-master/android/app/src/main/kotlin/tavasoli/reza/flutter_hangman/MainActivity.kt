package tavasoli.reza.flutter_hangman

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
